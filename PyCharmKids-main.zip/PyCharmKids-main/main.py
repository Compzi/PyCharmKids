import os
import uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from gigachat import GigaChat


####### ЗАГРУЗЧИК .ENV
def load_env():
    env = {}
    if os.path.exists('.env'):
        with open('.env', encoding='utf-8') as f:
            for line in f:
                if "=" in line and not line.strip().startswith("#"):
                    key, value = line.split("=", 1)
                    val = value.strip()

                    # Очищаем от любых видов кавычек (одинарных, двойных, обратных)
                    val = val.strip("'\"` ")
                    env[key.strip()] = val
    return env


env_ = load_env()

app = FastAPI(title="Gazprom AI Agent API (GigaChat)")

# --- НАСТРОЙКА GIGACHAT ---
GIGACHAT_CREDENTIALS = env_.get('AuthorizationKey')
GIGACHAT_SCOPE = "GIGACHAT_API_PERS"

# Вывод отладки токена в консоль при старте сервера
print("\n" + "=" * 50)
if GIGACHAT_CREDENTIALS:
    print(f"[СИСТЕМА]: Токен успешно прочитан.")
    print(f"[СИСТЕМА]: Длина токена: {len(GIGACHAT_CREDENTIALS)} симв.")
    print(f"[СИСТЕМА]: Начало токена: {GIGACHAT_CREDENTIALS[:15]}...")
else:
    print("[КРИТИЧЕСКАЯ ОШИБКА]: Переменная 'AuthorizationKey' не найдена в файле .env!")
print("=" * 50 + "\n")

# Инициализируем клиент GigaChat
gigachat_client = GigaChat(
    credentials=GIGACHAT_CREDENTIALS,
    scope=GIGACHAT_SCOPE,
    verify_ssl_certs=False
)


# Схема данных для входящих сообщений чата
class ChatMessage(BaseModel):
    message: str


@app.get("/", response_class=HTMLResponse)
async def get_dashboard():
    """Отдает интерфейс управления агентом."""
    with open("index.html", "r", encoding="utf-8") as file:
        return HTMLResponse(content=file.read())


@app.post("/api/v1/chat")
async def chat_endpoint(data: ChatMessage):
    """Принимает сообщение от пользователя, отправляет его в GigaChat

    и выводит логи в ваш Python-терминал.
    """
    user_text = data.message

    print(f"\n[ПОЛУЧЕНО ОТ ПОЛЬЗОВАТЕЛЯ]: {user_text}")
    print("[ЗАПРОС]: Отправка запроса в GigaChat API...")

    try:
        # Отправка запроса через официальный SDK
        response = gigachat_client.chat(user_text)

        # ТЕПЕРЬ ПРАВИЛЬНО: берем первый элемент из списка ответов choices[0]
        ai_response = response.choices[0].message.content
        print(f"[ОТВЕТ GIGACHAT]: {ai_response}\n")

    except Exception as e:
        ai_response = f"Ошибка при обращении к GigaChat: {str(e)}"
        print(f"[ОШИБКА API]: {ai_response}")

    return {"status": "success", "response": ai_response}


if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
